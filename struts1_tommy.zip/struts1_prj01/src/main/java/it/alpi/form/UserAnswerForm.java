package it.alpi.form;



public class UserAnswer{
	
	private String answer;
	


}
