package it.alpi.form;

import org.apache.struts.action.ActionForm;

public class WelcomeForm extends ActionForm{
	
	

}
